'''
This program is made to implement the trapezoid method to integrate a given function,
without knowing the form of the function. Thus, it will take in arrays of x and y coordinates of the function
to evaluate the area under the curve.

As a test, it will integrate f(x) = 2x on interval [0,10], which evaluates to 10^2-0^2=100
'''

import numpy as np

#on an interval [a,b], with a number of slices n,
#our step size is delta_x = (b-a)/n, so that n*delta_x = b-a
#for each i'th step a+i*delta_x, we find the trapezoid for sub interval
#[a+i*delta_x,a+(i+1)*delta_x]

def trapezoid_area(x1,x2,y):
    '''
    This function calculates the area of the trapezoid in the given interval.
    It takes in:
    x1 - the left boundary of the interval, x2 - the right boundary of the interval,
    and y - the array of y values for the curve
    and returns
    A - scalar area of the trapezoid
    '''
    h = x2 - x1#height of trapezoid, which in this case is on its side resting on x-axis
    a = y[int(x1)]#width of trapezoid top
    b = y[int(x2)]#width of trapezoid bottom
    A = (a+b)*(h/2)#trapezoid area formula
    return A

def integrator(x,y,a,b,n):
    '''
    This function breaks apart the interval [a,b] into n slices and approximates the area under the curve y on that interval.
    With inputs:
    x - array of x coordinates, y - array of y values at each x coordinate,
    a - left boundary, b - right boundary, n - number of steps to slice interval into
    Note: Use an n such that (b-a)/n is an integer, because it will be used for indexing
    
    '''
    area = 0
    delta_x = (b-a)/n
    for i in range(n):
        x_left = a+i*delta_x
        x_right = a+(i+1)*delta_x
        A = trapezoid_area(x_left,x_right,y)
        area += A
    return area

x = np.arange(11)
y = 2*x

I = integrator(x,y,0,10,5)
print(I)