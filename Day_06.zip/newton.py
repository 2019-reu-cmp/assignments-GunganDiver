'''
This program implements Newton's root finding method.
As a test, we'll use f(x) = sin(x) to find the root at x = pi
'''

import numpy as np

def f(x):#our function
    return np.sin(x)

def f1(x):#first derivative
    return np.cos(x)

def x_n_plus_1(x_n):
    '''
    calculates the next iteration of x value via Newton's method
    '''
    ratio = f(x_n)/f1(x_n)
    return x_n - ratio

def newton(x0,tol):
    '''
    given an initial x value, this function applies Newton's method until
    the change between the previous estimate and the current one is smaller than
    the specified tolerance
    '''
    x_list = [x0]
    x1 = x_n_plus_1(x0)
    x_list.append(x1)
    delta_x = x1 - x0
    iterations = 1
    while delta_x > tol:
        xi = x_n_plus_1(x_list[-1])
        x_list.append(xi)
        delta_x = x_list[-1]-x_list[-2]
        iterations += 1
    print('Newtons method ran for ',iterations,' iterations.')
    return x_list[-1]

x0 = 2.71
tolerance = 0.0001

x = newton(x0,tolerance)
print(x)