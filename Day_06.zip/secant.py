import numpy as np

def f(x):
    return np.sin(x)

def x_n_plus_1(x_n,x_n_minus_1):
    '''
    this function calculates the next term in the secant method given the two previous terms
    '''
    numerator = x_n-x_n_minus_1
    denominator = f(x_n) - f(x_n_minus_1)
    ratio = numerator/denominator
    return x_n - f(x_n)*ratio

def secant(x0,x1,tol):
    '''
    this function implements the secant root finding method and iterates until the change in successive terms
    is smaller than the specified tolerance.
    Note: For x0 and x1, one must correspond to a positive y-value and the other a negative y-value.
    '''
    x_list = [x0,x1]
    x2 = x_n_plus_1(x0,x1)
    print(x2)
    x_list.append(x2)
    delta_x = x2 - x1
    iterations = 1
    while delta_x > tol:
        xi = x_n_plus_1(x_list[-1],x_list[-2])
        x_list.append(xi)
        print(xi)
        iterations += 1
        delta_x = x_list[-1] - x_list[-2]
    print('Secant method ran for ',iterations,' iterations.')
    return x_list[-1]

x0 = 1.57
x1 = 4.71
tolerance = 0.0001

x = secant(x0,x1,tolerance)
print(x)