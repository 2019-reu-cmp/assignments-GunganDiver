import numpy as np
import matplotlib.pyplot as plt

filename = 'sunspots.txt'

with open(filename,'r') as f:
    lines = f.readlines()

sunspots = []

for line in lines:
    spl = line.split('\t')
    num_spots = spl[1].strip()
    sunspots.append(float(num_spots))

months = np.linspace(0,len(sunspots)-1,len(sunspots))
sunspots = np.array(sunspots)

months_to_find_avg = np.array([i*5 for i in range((len(sunspots)//5)+2)])
averages = [sunspots[0:m].mean() for m in months_to_find_avg]

plt.scatter(months,sunspots,s=3,label = 'Sunspots each month')
plt.scatter(months_to_find_avg,averages,label = 'Average sunspots over all months')
plt.xlabel('Months')
plt.ylabel('Number of Sunspots per month')
plt.legend()
plt.show()