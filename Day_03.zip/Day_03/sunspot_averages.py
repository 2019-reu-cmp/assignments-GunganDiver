import numpy as np

filename = 'sunspots.txt'

with open(filename,'r') as f:
    lines = f.readlines()

sunspots = []

for line in lines:
    spl = line.split('\t')
    num_spots = spl[1].strip()
    sunspots.append(float(num_spots))
    
avg = round(np.mean(sunspots),3)
print('The average number of sunspots in a day is: ',avg)

def compare(a,b,z):
    '''
    this function can tell if a number z lies between a and b. If so, it returns a one. If not, it returns a 0.
    '''
    if a > z:
        return 0
    elif a <= z:
        if z > b:
            return 0
        else:
            return 1

def count(low,high,array):
    '''
    with inputs low: lower bound, high: uppper bound
    and array: list of number of sunspots
    this counts and returns the number of days with
    an amount of sunspots between the two boundaries
    '''
    tally = 0
    for x in array:
        tally += compare(low,high,x)
    return tally

low = 50
high = 75
n = count(low,high,sunspots)
print('Number of days with more than ',low,' sunspots but less than ',high,':',n)