import math

def sum_term(k):
    '''
    this function evaluates a single term of the infinite series for pi
    '''
    numerator = math.factorial(4*k)*(1103+26390*k)
    denominator = ((math.factorial(k))**4)*(396**(4*k))
    return numerator/denominator

def srinivasa(n):
    """
    this function evaluates the infinite series to estimate pi, up to the nth term
    """
    coef = (1/9801)*2**(3/2)
    total = 0
    for k in range(n+1):#n+1 so the indexing goes up to n
        total += sum_term(k)
    return 1/(coef*total)#to return pi as opposed to 1/pi

if __name__ == '__main__':
    iterations = 3
    print(srinivasa(iterations))