from string import punctuation

filename = 'northwind.txt'

with open(filename,'r') as f:
    text = f.read()

words = text.split()

#preparing list of words by making them all lowercase and removing punctuation
def strip_punctuation(string):
    return ''.join(char for char in string if char not in punctuation)

for i,w in enumerate(words):
    l = w.lower()
    words[i] = strip_punctuation(l)

#preparing a dictionary to store the number of times a word appears with the word as the dictionary key
word_counts = {}

for word in words:
    if word in list(word_counts.keys()):
        word_counts[word] += 1
    else:
        word_counts[word] = 1

print(word_counts)